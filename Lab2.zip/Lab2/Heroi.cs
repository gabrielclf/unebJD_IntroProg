﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab2
{
    internal class Heroi
    {
        private string nome;
        private int ponto_vida;

        public Heroi (string nome, int ponto_vida)
        {
            this.nome = nome;
            this.ponto_vida = ponto_vida;
        }

        public string getNome() {  return nome; }
        public void setNome(string nome)
        {
            this.nome = nome;
        }

        public int getPonto_vida() {  return ponto_vida; }
        public void setPonto_vida(int ponto_vida)
        {
            this.ponto_vida = ponto_vida;
        }

        public void LancarMagia()
        {

        }

        public void AtacarComArma()
        {

        }

        public void AumentarVida(int hp)
        {
            ponto_vida += hp;
        }

        public void ReduzirVida(int hp)
        {
            ponto_vida -= hp;
        }
    }
}
